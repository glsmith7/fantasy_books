# settings file

PATH_DEFAULT = "./sqlite_db/ACKS_SQL_01.db3"
SQL_QUERY_DEFAULT = "SELECT * FROM '_replace_'"
TABLE_NAME_DEFAULT = "MercenaryTableCities"
DEFAULT_RACE = 'Human'

# PATH_DEFAULT = "./tests/testSQL.db3"
# SQL_QUERY_DEFAULT = "SELECT * FROM '_replace_'"
# TABLE_NAME_DEFAULT = "TestTableReactionRollStandard"