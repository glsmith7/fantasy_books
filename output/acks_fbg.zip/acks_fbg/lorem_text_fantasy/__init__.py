"""Top-level package for Lorem Text."""

__author__ = """Abhijeet Pal"""
__version__ = "2.1"
